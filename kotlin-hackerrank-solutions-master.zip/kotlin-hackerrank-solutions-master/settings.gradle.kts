
rootProject.name = "kotlin-hackerrank-solutions"

